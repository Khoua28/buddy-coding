# buddy-coding
web game as a better appoach of coding
